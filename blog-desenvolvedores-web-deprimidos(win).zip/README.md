# Desenvolvedores Web Deprimidos
### Para quando a API REST retornar um documento XML.

Um simples blog ficcional.
